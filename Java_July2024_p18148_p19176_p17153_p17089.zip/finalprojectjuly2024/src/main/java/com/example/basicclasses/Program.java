package com.example.basicclasses;

public class Program {
    private String name;
    private String benefits;
    private double baseCharge;
    private double additionalCharges;

    public Program(String name, String benefits, double baseCharge, double additionalCharges) {
        this.name = name;
        this.benefits = benefits;
        this.baseCharge = baseCharge;
        this.additionalCharges = additionalCharges;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBenefits() {
        return benefits;
    }

    public void setBenefits(String benefits) {
        this.benefits = benefits;
    }

    public double getBaseCharge() {
        return baseCharge;
    }

    public void setBaseCharge(double baseCharge) {
        this.baseCharge = baseCharge;
    }

    public double getAdditionalCharges() {
        return additionalCharges;
    }

    public void setAdditionalCharges(double additionalCharges) {
        this.additionalCharges = additionalCharges;
    }
}
