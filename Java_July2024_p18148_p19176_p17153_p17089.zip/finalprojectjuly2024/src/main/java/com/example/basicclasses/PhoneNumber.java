package com.example.basicclasses;


public class PhoneNumber {
    private String number;
    private String plan;

    public PhoneNumber(String number, String plan) {
        this.number = number;
        this.plan = plan;
    }

    // Getters and Setters
    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPlan() {
        return plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }
}