package com.example.basicclasses;
import java.util.List;
public class Bill {
    private String billingMonth;
    private PhoneNumber phoneNumber;
    private List<Call> callList;

    // Constructor
    public Bill(String billingMonth, PhoneNumber phoneNumber, List<Call> callList) {
        this.billingMonth = billingMonth;
        this.phoneNumber = phoneNumber;
        this.callList = callList;
    }

    // Getters and Setters
    public String getBillingMonth() {
        return billingMonth;
    }

    public void setBillingMonth(String billingMonth) {
        this.billingMonth = billingMonth;
    }

    public PhoneNumber getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(PhoneNumber phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public List<Call> getCallList() {
        return callList;
    }

    public void setCallList(List<Call> callList) {
        this.callList = callList;
    }
}
