package com.example.basicclasses;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;

public class Seller extends Users {
    public Seller(String username, String name, String surname, String userType) {
        super(username, name, surname, userType);
    }

    public static void logout() {
        System.out.println("User logged out successfully.");
    }
    static void registerNewCustomer() {
        try {
            Scanner myObj = new Scanner(System.in);
            String userName;
            String name;
            String surname;
            int AFM;
            String arithmos;
            System.out.println("Eisagete to username, onoma, eponymo, AFM,  kai arithmo thlefonou");
            userName = myObj.nextLine();
            name = myObj.nextLine();
            surname = myObj.nextLine();
            AFM = myObj.nextInt();
            myObj.nextLine();
            arithmos = myObj.nextLine();
            String afm_as_string = String.valueOf(AFM);
            FileWriter myWriter = new FileWriter("clients.txt", true);
            myWriter.write(userName);
            myWriter.write(" , ");
            myWriter.write(name);
            myWriter.write(" , ");
            myWriter.write(surname);
            myWriter.write(" , ");
            myWriter.write(afm_as_string);
            myWriter.write(" , ");
            myWriter.write(arithmos);
            myWriter.write('\n');
            myWriter.close();
            System.out.println("Epituxhs apothikeusi.");
        }
        catch (IOException e) {
            System.out.println("Lathos egine.");
            e.printStackTrace();
        }
    }

    static void issueCustomerAccount() {
        try {
            Scanner myObj = new Scanner(System.in);
            String userName;
            String name;
            String surname;
            int AFM;
            String arithmos;
            String expirationDate;
            float amount;
            System.out.println("Eisagete to username, onoma, eponymo, AFM,arithmo thlefonou, poso pliromis kai imerominia lixis");
            userName = myObj.nextLine();
            name = myObj.nextLine();
            surname = myObj.nextLine();
            AFM = myObj.nextInt();
            myObj.nextLine();
            arithmos = myObj.nextLine();
            amount = myObj.nextFloat();
            myObj.nextLine();
            String afm_as_string = String.valueOf(AFM);
            String amount_as_string = String.valueOf(amount);
            expirationDate = myObj.nextLine();
            FileWriter myWriter = new FileWriter("accounts.txt", true);
            myWriter.write(userName);
            myWriter.write(" , ");
            myWriter.write(name);
            myWriter.write(" , ");
            myWriter.write(surname);
            myWriter.write(" , ");
            myWriter.write(afm_as_string);
            myWriter.write(" , ");
            myWriter.write(arithmos);
            myWriter.write(" , ");
            myWriter.write(amount_as_string);
            myWriter.write(" , ");
            myWriter.write(expirationDate);
            myWriter.write('\n');
            myWriter.close();
            System.out.println("Epituxhs apothikeusi.");
            System.out.println("Oi logariasmoi gia auton ton mina einai: ");
            String logariasmoi = "accounts.txt";
            try {
                BufferedReader reader = new BufferedReader(new FileReader(logariasmoi));
                String line = reader.readLine();
                while (line != null) {
                    System.out.println(line);
                    line = reader.readLine();
                }
                reader.close();
            } catch (IOException e) {
                System.err.println("Error reading the file: " + e.getMessage());
            }
        }
        catch (IOException e) {
            System.out.println("Lathos egine.");
            e.printStackTrace();
        }
    }
    public void register() {
        Scanner registering = new Scanner(System.in);
        System.out.println("Enter username,name,surname,password");
        String username = registering.nextLine();
        String name = registering.nextLine();
        String surname = registering.nextLine();
        String password = registering.nextLine();
        System.out.println("Seller registered");
    }
    static void changeCustomerPlan() {
        // Implementation for changing a customer's plan
    }
    public static void main (String[] args) {
        Scanner re = new Scanner(System.in);
        System.out.println("PRESS 1 TO REGISTER NEW CUSTOMER");
        System.out.println("PRESS 2 TO ISSUE CUSTOMER ACCOUNT");
        System.out.println("PRESS 3 TO CHANGE CUSTOMER'S PLAN");
        System.out.println("PRESS 4 TO LOG OUT");
        System.out.println("Your choice: ");
        int number = re.nextInt();
        // Validate the input.
        while (number < 1 || number > 4) {
            System.out.println("Mh egkyrh epilogh.");
            System.out.println("PRESS 1 TO REGISTER NEW CUSTOMER");
            System.out.println("PRESS 2 TO ISSUE CUSTOMER ACCOUNT");
            System.out.println("PRESS 3 TO CHANGE CUSTOMER'S PLAN");
            System.out.println("PRESS 4 TO LOG OUT");
            System.out.println("Your choice: ");
            number = re.nextInt();
        }
        if (number==1) {
            registerNewCustomer();
        }else if (number==2) {
            issueCustomerAccount();
        }else if (number==3) {
            changeCustomerPlan();
        }else if (number==4) {
            logout();
        }
    }
}
