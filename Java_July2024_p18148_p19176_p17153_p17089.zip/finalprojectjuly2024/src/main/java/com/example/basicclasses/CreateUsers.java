package com.example.basicclasses;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.*;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;


public class CreateUsers {
    public static void main(String[] args) {
        Client client = new Client("re_pou_Pame","michalis","giannakopoulos","client","32110",3232);
        Seller seller = new Seller("ford","themistoklis","dimitriou","seller");
        Admin admin = new Admin("plimiraC","andreas","papadopoulos","admin");
        System.out.println("Objects created");
        System.out.println(client.getUsername());
        System.out.println(client.getName());
        System.out.println(client.getSurname());
        System.out.println(client.getUserType());
        System.out.println('\n');
        System.out.println(seller.getUsername());
        System.out.println(seller.getName());
        System.out.println(seller.getSurname());
        System.out.println(seller.getUserType());
        System.out.println('\n');
        System.out.println(admin.getUsername());
        System.out.println(admin.getName());
        System.out.println(admin.getSurname());
        System.out.println(admin.getUserType());
    }
}