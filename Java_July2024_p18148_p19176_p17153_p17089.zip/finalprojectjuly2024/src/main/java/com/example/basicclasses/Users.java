package com.example.basicclasses;

public class Users {
    private String username;
    private String name;
    private String surname;
    private String userType;
    private static int userCounter = 0;

    public Users(String username, String name, String surname, String userType) {
        this.username = username;
        this.name = name;
        this.surname = surname;
        this.userType = userType;
        userCounter++;
    }
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public static int getUserCounter() {
        return userCounter;
    }

    public void register() {
        // Register logic
    }

    public void login() {
        // Login logic
    }

    public static void logout() {
        // Logout logic
    }
}
