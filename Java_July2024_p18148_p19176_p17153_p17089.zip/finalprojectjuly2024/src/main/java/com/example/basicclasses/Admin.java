package com.example.basicclasses;
import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.*;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;


public class Admin extends Users {
    public Admin(String username, String name, String surname, String userType) {
        super(username, name, surname, userType);
    }

    static void createSeller() {
        try {
            Scanner myObj = new Scanner(System.in);
            String userName;
            String name;
            String surname;
            System.out.println("Eisagete to username, onoma kai eponymo");
            userName = myObj.nextLine();
            name = myObj.nextLine();
            surname = myObj.nextLine();
            FileWriter myWriter = new FileWriter("sellers.txt", true);
            myWriter.write(userName);
            myWriter.write(" , ");
            myWriter.write(name);
            myWriter.write(" , ");
            myWriter.write(surname);
            myWriter.write(" , ");
            myWriter.write("seller");
            myWriter.write('\n');
            myWriter.close();
            System.out.println("Epituxhs apothikeusi.");
        } catch (Exception e) {
            System.out.println("Lathos egine.");
            e.printStackTrace();
        }
    }
    static void createClient() {
        try {
            Scanner myObj = new Scanner(System.in);
            String userName;
            String name;
            String surname;
            int AFM;
            String arithmos;
            System.out.println("Eisagete to username, onoma, eponymo, AFM,  kai arithmo thlefonou");
            userName = myObj.nextLine();
            name = myObj.nextLine();
            surname = myObj.nextLine();
            AFM = myObj.nextInt();
            myObj.nextLine();
            arithmos = myObj.nextLine();
            String afm_as_string = String.valueOf(AFM);
            FileWriter myWriter = new FileWriter("clients.txt", true);
            myWriter.write(userName);
            myWriter.write(" , ");
            myWriter.write(name);
            myWriter.write(" , ");
            myWriter.write(surname);
            myWriter.write(" , ");
            myWriter.write(afm_as_string);
            myWriter.write(" , ");
            myWriter.write(arithmos);
            myWriter.write('\n');
            myWriter.close();
            System.out.println("Epituxhs apothikeusi.");
        }
        catch (IOException e) {
            System.out.println("Lathos egine.");
            e.printStackTrace();
        }
    }

    static void deleteSeller() throws IOException {
        System.out.println("Poion politi na diagrapso;");
        Scanner myObj = new Scanner(System.in);
        String userName = myObj.nextLine();
        Path fileName = Path.of("C:\\Users\\tasos\\Desktop\\JavaProject1\\sellers.txt");
        String str = Files.readString(fileName);
        if (str.contains(userName)){
            System.out.println("O pelatis diagrafike");
            FileWriter myWriter = new FileWriter("clients.txt");
            myWriter.write(str.replace(userName, " "));
            myWriter.close();

        }
        else{
            System.out.println("O politis den einai kataxorimenos");
        }
    }
    static void deleteClient() throws IOException{
        System.out.println("Poion pelati na diagrapso;");
        Scanner myObj = new Scanner(System.in);
        String userName = myObj.nextLine();
        Path fileName = Path.of("C:\\Users\\tasos\\Desktop\\JavaProject1\\clients.txt");
        String str = Files.readString(fileName);
        if (str.contains(userName)){
            System.out.println("O pelatis diagrafike");
            FileWriter myWriter = new FileWriter("clients.txt");
            myWriter.write(str.replace(userName, " "));
            myWriter.close();

        }
        else{
            System.out.println("O pelatis den einai kataxorimenos");
        }
    }
    public static void logout() {
        System.out.println("User logged out successfully.");
    }
    static void createProgram() {
        try {
            Scanner myObj = new Scanner(System.in);
            int programNumber;
            String programname;
            String description;
            System.out.println("Eisagete arithmo programmatos, onoma programmatos, perigrafi");
            programNumber = myObj.nextInt();
            String programNumber_as_string = String.valueOf(programNumber);
            myObj.nextLine();
            programname = myObj.nextLine();
            description = myObj.nextLine();
            FileWriter myWriter = new FileWriter("program.txt", true);
            myWriter.write(programNumber_as_string);
            myWriter.write(" , ");
            myWriter.write(programname);
            myWriter.write(" , ");
            myWriter.write(description);
            myWriter.write('\n');
            myWriter.close();
            System.out.println("Epituxhs apothikeusi.");
        }
        catch (IOException e) {
            System.out.println("Lathos egine.");
            e.printStackTrace();
        }
    }

    public static void main (String[] args) throws IOException {
        Scanner tieginerepaidia = new Scanner(System.in);
        System.out.println("1. Create seller");
        System.out.println("2. Create client");
        System.out.println("3. Delete seller");
        System.out.println("4. Delete client");
        System.out.println("5. Create program");
        System.out.println("6. Log out");
        System.out.println("Your choice: ");
        int eisodos = tieginerepaidia.nextInt();
        // Validate the input.
        while (eisodos < 1 || eisodos > 6) {
            System.out.println("Mh egkyrh epilogh.");
            System.out.println("1. Create seller");
            System.out.println("2. Create client");
            System.out.println("3. Delete seller");
            System.out.println("4. Delete client");
            System.out.println("5. Create program");
            System.out.println("6. Log out");
            System.out.println("Your choice: ");

        }
        if(eisodos==1) {
            createSeller();
        }
        else if(eisodos==2) {
            createClient();
        }
        else if(eisodos==3) {
            deleteSeller();
        }
        else if(eisodos==4) {
            deleteClient();
        }
        else if(eisodos==5) {
            createProgram();
        }
        else if(eisodos==6) {
            logout();
        }
      }
    }
