package com.example.basicclasses;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Client extends Users {
    private String phoneNumber;
    private final int AFM;

    public Client(String username, String name, String surname, String property, String phoneNumber, int AFM) {
        super(username, name, surname, property);
        this.phoneNumber = phoneNumber;
        this.AFM = AFM;
    }

    public static void viewAccount() {
        Scanner search = new Scanner(System.in);
        System.out.println("Enter your username");
        String input = search.nextLine();
        String usernameToSearch = input;
        File file = new File("accounts.txt");

        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (line.contains(usernameToSearch)) {
                    System.out.println("Username found: " + usernameToSearch);
                    System.out.println(line);
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
    }

    public static void viewCallHistory() {
        // View call history logic
    }

    public static void payBill() {
        System.out.println("Bill was paid.");
    }
    public void register() {
        Scanner registering = new Scanner(System.in);
        System.out.println("Enter username,name,surname,password,phone number, afm");
        String username = registering.nextLine();
        String name = registering.nextLine();
        String surname = registering.nextLine();
        String password = registering.nextLine();
        String phone = registering.nextLine();
        int afm = registering.nextInt();
        System.out.println("Client registered");
    }

    public void login() {
        System.out.println("User logged in successfully.");
    }

    public static void logout() {
        System.out.println("User logged out successfully.");
    }


    public static void main(String[] args)  {
        Scanner scanner = new Scanner(System.in);
        System.out.println("PRESS 1 TO VIEW ACCOUNT, 2 TO VIEW CALL HISTORY, 3 TO PAY YOUR BILL OR 4 TO LOGOUT. ");
        System.out.println("Your choice: ");
        int number = scanner.nextInt();
        // Validate the input.
        while (number < 1 || number > 4) {
            System.out.println("Mh egkyrh epilogh.");
            System.out.println("PRESS 1 TO VIEW ACCOUNT, 2 TO VIEW CALL HISTORY 3 TO PAY YOUR BILL OR 4 TO LOGOUT. ");
            System.out.println("Your choice: ");
            number = scanner.nextInt();
        }
        if (number==1) {
            viewAccount();
        } else if (number==2) {
            viewCallHistory();
        } else if (number==3) {
            payBill();
        } else if (number==4) {
            logout();
        }
    }


}