package com.example.basicclasses;

import java.util.Scanner;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.File;

public class Call {
    private String caller;
    private String receiver;
    private int durationInSeconds;

    public Call(String caller, String receiver, int durationInSeconds) {
        this.caller = caller;
        this.receiver = receiver;
        this.durationInSeconds = durationInSeconds;
    }

    public Call() {

    }

    public String getCaller() {
        return caller;
    }

    public String getReceiver() {
        return receiver;
    }

    public int getDurationInSeconds() {
        return durationInSeconds;
    }

    public void setCaller(String caller) {
        this.caller = caller;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public void setDurationInSeconds(int durationInSeconds) {
        this.durationInSeconds = durationInSeconds;
    }
    public static void main(String[] args) {
        Scanner eisodos = new Scanner(System.in);
        Call myobj = new Call();
        System.out.println("Eisagete ton kalounta, ton kaloumeno , kai tin diarkeia se deuterolepta");
        String caller = eisodos.nextLine();
        String receiver = eisodos.nextLine();
        int seconds = eisodos.nextInt();
        myobj.setCaller(caller);
        myobj.setReceiver(receiver);
        myobj.setDurationInSeconds(seconds);
        String seconds_to_string = Integer.toString(seconds);
        try {
            FileWriter myWriter = new FileWriter("calls.txt",true);
            myWriter.write(caller);
            myWriter.write(",");
            myWriter.write(receiver);
            myWriter.write(",");
            myWriter.write(seconds_to_string);
            myWriter.write('\n');
            myWriter.close();
            System.out.println("Ta apothikeusa sto arxeio epityxos.");
        }
        catch (IOException e) {
            System.out.println("Oooooooop! Lathos egine.");
            e.printStackTrace();
        }
    }
}
