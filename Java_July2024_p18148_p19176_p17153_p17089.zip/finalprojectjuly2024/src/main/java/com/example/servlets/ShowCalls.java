package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;

public class ShowCalls extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");
        out.println("<html><body>");
        String onomaxristi = request.getParameter("onomaxristi");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Create Connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb", "root", "webprogrammingunipi");

            //Create Statement for database query
            PreparedStatement ps = con.prepareStatement("select * from calls where caller=?");
            ps.setString(1, onomaxristi);
            ResultSet rs = ps.executeQuery();
            PreparedStatement ps2 = con.prepareStatement("select * from calls where receiver=?");
            ps2.setString(1, onomaxristi);
            ResultSet rs2 = ps2.executeQuery();
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>caller</th><th>receiver</th><th>duration</th><tr>");
            while (rs.next())
            {
                String caller = rs.getString("caller");
                String receiver = rs.getString("receiver");
                int duration = rs.getInt("duration");
                out.println("<tr><td>" + caller + "</td><td>" + receiver + "</td><td>" + duration + "</td></tr>");
            }
            while (rs2.next())
            {
                String caller = rs2.getString("caller");
                String receiver = rs2.getString("receiver");
                int duration = rs2.getInt("duration");
                out.println("<tr><td>" + caller + "</td><td>" + receiver + "</td><td>" + duration + "</td></tr>");
            }
            out.println("</table>");
            out.println("</html></body>");
            con.close();
        }catch (Exception e2) {
            out.println("error");
        }
    }
}
