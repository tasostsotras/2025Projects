package com.example.servlets;

import jakarta.servlet.http.HttpServlet;
import java.io.*;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
public class SwitchPlanInfo extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

//Retrieve username and Password
        String onoma=request.getParameter("onoma");
        String benefits=request.getParameter("benefits");
        String basecharge=request.getParameter(String.valueOf("basecharge"));
        String extracharge=request.getParameter(String.valueOf("extracharge"));
        try{
            Class.forName("com.mysql.jdbc.Driver");
//Create Connection
            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb","root","webprogrammingunipi");
            PreparedStatement ps2 = con.prepareStatement("select * from programs where onoma=? and benefits=? and basecharge=? and extracharge=? ");
            ps2.setString(1,onoma);
            ps2.setString(2,benefits);
            ps2.setString(3,basecharge);
            ps2.setString(4,extracharge);
            ResultSet rs = ps2.executeQuery();
            if (rs.next()) {
                out.print("<h4>Sorry, the program already has these attributes!</h4>");
                request.getRequestDispatcher("switchplaninfo.html").include(request, response);
            } else {
//Create Statement for inserting details to table
                PreparedStatement ps = con.prepareStatement("UPDATE programs SET onoma=? , benefits=? , basecharge=? , extracharge=? WHERE onoma=?");
                ps.setString(1, onoma);
                ps.setString(2, benefits);
                ps.setString(3, basecharge);
                ps.setString(4, extracharge);
                ps.setString(5, onoma);
                int i = ps.executeUpdate();
                if (i > 0)
                    out.print("The program info are updated!");

            }
        }catch (Exception e2) {System.out.println(e2);}

        out.close();
    }

}

