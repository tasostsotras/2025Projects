package com.example.servlets;

import java.io.*;
import java.security.SecureRandom;
import java.sql.*;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.MessageDigest;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
public class PublishTheBill extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

//Retrieve username and Password
        String onomaxristi=request.getParameter("onomaxristi");
        String poson=request.getParameter(String.valueOf("poson"));
        String expirationdate=request.getParameter("expirationdate");
        String paid=request.getParameter(String.valueOf("paid"));


        try{
            Class.forName("com.mysql.jdbc.Driver");
//Create Connection
            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb","root","webprogrammingunipi");
            PreparedStatement user_exists = con.prepareStatement("select * from clients where onomaxristi=?");
            user_exists.setString(1, onomaxristi);
            ResultSet rs_exists = user_exists.executeQuery();
            if (!rs_exists.next()) {
                out.print("<h4>THIS USER DOESN'T EXIST!");
                request.getRequestDispatcher("publishthebill.html").include(request, response);
            }
            else {


                PreparedStatement ps2 = con.prepareStatement("select * from bill where onomaxristi=?");
                ps2.setString(1, onomaxristi);

                ResultSet rs = ps2.executeQuery();
                if (rs.next()) {
                    out.print("<h4>Account already published for this user</h4>");
                    request.getRequestDispatcher("publishthebill.html").include(request, response);
                } else {

                    PreparedStatement ps = con.prepareStatement(
                            "insert into bill values(?,?,?,?)");

                    ps.setString(1, onomaxristi);
                    ps.setString(2, poson);
                    ps.setString(3, expirationdate);
                    ps.setString(4, paid);

                    int i = ps.executeUpdate();
                    if (i > 0)
                        out.print("Published!");

                }
            }
        }catch (Exception e2) {System.out.println(e2);}

        out.close();
    }


}
