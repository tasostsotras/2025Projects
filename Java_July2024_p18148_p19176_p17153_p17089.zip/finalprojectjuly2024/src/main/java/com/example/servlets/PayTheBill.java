package com.example.servlets;

import java.io.*;
import java.security.SecureRandom;
import java.sql.*;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.MessageDigest;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
public class PayTheBill extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String onomaxristi=request.getParameter("onomaxristi");
        String poson=request.getParameter(String.valueOf("poson"));
        try{
            Class.forName("com.mysql.jdbc.Driver");
//Create Connection
            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb","root","webprogrammingunipi");
            PreparedStatement user_exists = con.prepareStatement("select * from bill where onomaxristi=? and poson=?");
            user_exists.setString(1, onomaxristi);
            user_exists.setString(2, poson);
            ResultSet rs_exists = user_exists.executeQuery();
            if (!rs_exists.next()) {
                out.print("<h4>There is no bill for this user with this amount");
                request.getRequestDispatcher("paythebill.jsp").include(request, response);
            }
            else {


                PreparedStatement ps2 = con.prepareStatement("select * from bill where onomaxristi=? and paid=1");
                ps2.setString(1, onomaxristi);

                ResultSet rs = ps2.executeQuery();
                if (rs.next()) {
                    out.print("<h4>Bill already paid</h4>");
                    request.getRequestDispatcher("paythebill.jsp").include(request, response);
                } else {
                    PreparedStatement ps = con.prepareStatement(
                            "UPDATE bill SET paid=1 WHERE onomaxristi=? and poson=?");

                    ps.setString(1, onomaxristi);
                    ps.setString(2, poson);
                    int i = ps.executeUpdate();
                    if (i > 0)
                        out.print("Paid!");

                }
            }
        }catch (Exception e2) {System.out.println(e2);}

        out.close();
    }

}
