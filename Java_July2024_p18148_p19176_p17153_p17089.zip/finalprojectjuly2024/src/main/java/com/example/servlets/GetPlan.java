package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class GetPlan extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

//Retrieve username and Password
        String onomaxristi = request.getParameter("username");
        String onomaprogrammatos = request.getParameter("program");
        try {
            Class.forName("com.mysql.jdbc.Driver");
//Create Connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb", "root", "webprogrammingunipi");
            PreparedStatement userexists = con.prepareStatement("select * from clients where onomaxristi=?");
            userexists.setString(1, onomaxristi);
            ResultSet rsuserexists = userexists.executeQuery();
            if (!rsuserexists.next()) {
                out.print("<h4>Error: No such user exists");
            } else {
                PreparedStatement ps2 = con.prepareStatement("select * from clientsinprograms where onomaxristi=?");
                ps2.setString(1, onomaxristi);
                ResultSet rs = ps2.executeQuery();
                if (rs.next()) {
                    out.print("<h4>Error: The user with this username has already been registered to a program!</h4>");
                    request.getRequestDispatcher("getplan.html").include(request, response);
                } else {
                    PreparedStatement ps3 = con.prepareStatement("select * from programs where onoma=?");
                    ps3.setString(1, onomaprogrammatos);
                    ResultSet rs3 = ps3.executeQuery();
                    if (!rs3.next()) {
                        out.print("<h4>Error: No such program exists");
                    } else {
//Create Statement for inserting details to table
                        PreparedStatement ps = con.prepareStatement(
                                "insert into clientsinprograms values(?,?)");

                        ps.setString(1, onomaxristi);
                        ps.setString(2, onomaprogrammatos);
                        int i = ps.executeUpdate();
                        if (i > 0)
                            out.print("You activated the plan!");
                        request.getRequestDispatcher("getplan.html").include(request, response);
                    }
                }
            }
        } catch (Exception e2) {
            System.out.println(e2);
        }

        out.close();
    }
}