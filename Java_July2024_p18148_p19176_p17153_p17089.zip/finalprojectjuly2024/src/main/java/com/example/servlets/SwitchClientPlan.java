package com.example.servlets;

import jakarta.servlet.http.HttpServlet;
import java.io.*;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;

public class SwitchClientPlan extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String onomaxristi=request.getParameter("onomaxristi");
        String onomaprogrammatos=request.getParameter("onomaprogrammatos");
        try{
            Class.forName("com.mysql.jdbc.Driver");
//Create Connection
            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb","root","webprogrammingunipi");

            PreparedStatement user_check = con.prepareStatement("select * from clientsinprograms where onomaxristi=? ");
            user_check.setString(1,onomaxristi);
            ResultSet rs = user_check.executeQuery();
            if (!rs.next()) {
                out.print("<h4>No such user found!</h4>");
                request.getRequestDispatcher("switchclientplan.html").include(request, response);
            } else {
                PreparedStatement plan_check = con.prepareStatement("select * from programs where onoma=?");
                plan_check.setString(1,onomaprogrammatos);
                ResultSet rs_plan = plan_check.executeQuery();
                if (!rs_plan.next()) {
                    out.print("<h4>No such program found</h4>");
                    request.getRequestDispatcher("switchclientplan.html").include(request,response);
                } else {
                    PreparedStatement plan_change = con.prepareStatement("UPDATE clientsinprograms SET onomaxristi=?, onomaprogrammatos=? WHERE onomaxristi=?");
                    plan_change.setString(1, onomaxristi);
                    plan_change.setString(2, onomaprogrammatos);
                    plan_change.setString(3, onomaxristi);
                    int i = plan_change.executeUpdate();
                    if (i > 0)
                        out.print("The client's program info are updated!");
                }
            }
        }catch (Exception e2) {System.out.println(e2);}

        out.close();
    }
}
