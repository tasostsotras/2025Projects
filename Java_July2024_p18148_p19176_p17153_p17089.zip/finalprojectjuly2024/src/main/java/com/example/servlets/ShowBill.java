package com.example.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;

public class ShowBill extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");
        out.println("<html><body>");
        //Retrieve username
        String onomaxristi = request.getParameter("onomaxristi");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Create Connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb", "root", "webprogrammingunipi");

            //Create Statement for database query
            PreparedStatement ps = con.prepareStatement("select * from bill where onomaxristi=?");
            ps.setString(1, onomaxristi);
            ResultSet rs = ps.executeQuery();
            out.println("<table border=1 width=50% height=50%>");
            out.println("<tr><th>onomaxristi</th><th>poson</th><th>ExpirationDate</th><th>Paid</th><tr>");
            while (rs.next())
            {
                String nameofuser = rs.getString("onomaxristi");
                float amount = rs.getFloat("poson");
                String date = rs.getString(String.valueOf("expirationdate"));
                int paid_or_not = rs.getInt("paid");
                out.println("<tr><td>" + nameofuser + "</td><td>" + amount + "</td><td>" + date + "</td><td>"+paid_or_not+ "</td></tr>");
            }
            out.println("</table>");
            out.println("</html></body>");
            con.close();

    }catch (Exception e2) {
            out.println("error");
        }

    }
}
