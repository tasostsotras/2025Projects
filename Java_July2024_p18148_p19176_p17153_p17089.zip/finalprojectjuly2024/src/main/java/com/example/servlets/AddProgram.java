package com.example.servlets;

import jakarta.servlet.http.HttpServlet;
import java.io.*;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
public class AddProgram extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

//Retrieve username and Password
        String onoma=request.getParameter("onoma");
        String benefits=request.getParameter("benefits");
        String basecharge=request.getParameter(String.valueOf("basecharge"));
        String extracharge=request.getParameter(String.valueOf("extracharge"));


        try{
            Class.forName("com.mysql.jdbc.Driver");
//Create Connection
            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb","root","webprogrammingunipi");
            PreparedStatement ps2 = con.prepareStatement("select * from programs where onoma=?");
            ps2.setString(1,onoma);
            ResultSet rs = ps2.executeQuery();
            if (rs.next()) {
                out.print("<h4>Sorry, there is already program with this name!</h4>");
                request.getRequestDispatcher("enternewplan.html").include(request, response);
            } else {
//Create Statement for inserting details to table
                PreparedStatement ps = con.prepareStatement(
                        "insert into programs values(?,?,?,?)");

                ps.setString(1, onoma);
                ps.setString(2, benefits);
                ps.setString(3, basecharge);
                ps.setString(4, extracharge);

                int i = ps.executeUpdate();
                if (i > 0)
                    out.print("The program was added!");

            }
        }catch (Exception e2) {System.out.println(e2);}

        out.close();
    }

}
