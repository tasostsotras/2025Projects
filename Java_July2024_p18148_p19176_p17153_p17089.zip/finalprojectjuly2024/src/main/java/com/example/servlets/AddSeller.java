package com.example.servlets;

import java.io.*;
import java.security.SecureRandom;
import java.sql.*;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.MessageDigest;
import java.util.Base64;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
public class AddSeller extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

//Retrieve username and Password
        String onomaxristi=request.getParameter("username");
        String onoma=request.getParameter("firstname");
        String surname=request.getParameter("lastname");
        String password=request.getParameter("password");
        byte[] salt = generateSalt();
        String hashedPassword = hashPassword(password, salt);


        try{
            Class.forName("com.mysql.jdbc.Driver");
//Create Connection
            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb","root","webprogrammingunipi");
            PreparedStatement ps2 = con.prepareStatement("select * from sellers where onomaxristi=? or password=? ");
            ps2.setString(1,onomaxristi);
            ps2.setString(2,hashedPassword);
            ResultSet rs = ps2.executeQuery();
            if (rs.next()) {
                out.print("<h4>Sorry, username or password already exists!</h4>");
                request.getRequestDispatcher("enterseller.html").include(request, response);
            } else {
//Create Statement for inserting details to table
                PreparedStatement ps = con.prepareStatement(
                        "insert into sellers values(?,?,?,?)");

                ps.setString(1, onomaxristi);
                ps.setString(2, onoma);
                ps.setString(3, surname);
                ps.setString(4, hashedPassword);

                int i = ps.executeUpdate();
                if (i > 0)
                    out.print("The seller is successfully registered");

            }
        }catch (Exception e2) {System.out.println(e2);}

        out.close();
    }
    private static byte[] generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return salt;
    }

    private static String hashPassword(String password, byte[] salt) {
        String hashedPassword = null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(salt);
            byte[] hashedBytes = md.digest(password.getBytes());
            hashedPassword = Base64.getEncoder().encodeToString(hashedBytes);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return hashedPassword;
    }

}
