package com.example.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.*;
import java.util.Base64;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
public class AdminLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        //Retrieve username and Password
        String onomaxristi = request.getParameter("username");
        String password = request.getParameter("password");
        String salt = generateSalt();
        String storedPassword = hashPassword(password, salt);
        HttpSession session=request.getSession();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //Create Connection
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/projectdb", "root", "webprogrammingunipi");

            //Create Statement for database query
            PreparedStatement ps = con.prepareStatement("select * from admins where onomaxristi=?");
            ps.setString(1, onomaxristi);
            //execute query
            ResultSet rs = ps.executeQuery();
            //check if result exists
            if (rs.next() && validatePassword(password, storedPassword, salt)) {
                //if exists, then create session attribute and redirect user to authenticated page
                session.setAttribute("logindetail", onomaxristi + storedPassword + salt);
                String username = (String) session.getAttribute(onomaxristi);
                response.getWriter().println("Username from Session: " + username);
                response.sendRedirect("adminmenu.html?name="+onomaxristi);
            } else {
                //if not exists, prompt user.
                out.print("<h4>Sorry, username or password is incorrect!</h4>");
                request.getRequestDispatcher("adminlogin.jsp").include(request, response);
            }
        } catch (Exception e2) {
            System.out.println(e2);
        }

        out.close();

    }
    public static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }
    public static String hashPassword(String password, String salt) {
        String hashedPassword = null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(Base64.getDecoder().decode(salt));
            byte[] bytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte aByte : bytes) {
                sb.append(Integer.toString((aByte & 0xff) + 0x100, 16).substring(1));
            }
            hashedPassword = sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return hashedPassword;
    }
    public static boolean validatePassword(String password, String storedPassword, String salt) {
        String hashedEnteredPassword = hashPassword(password, salt);
        return hashedEnteredPassword.equals(storedPassword);
    }

}
