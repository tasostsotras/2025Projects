﻿namespace FirstCall
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.fIRSTCALLDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fIRSTCALLDataSet = new FirstCall.FIRSTCALLDataSet();
            this.phoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.phoneTableAdapter = new FirstCall.FIRSTCALLDataSetTableAdapters.PhoneTableAdapter();
            this.phoneBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.paymentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.paymentsTableAdapter = new FirstCall.FIRSTCALLDataSetTableAdapters.PaymentsTableAdapter();
            this.casesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.casesTableAdapter = new FirstCall.FIRSTCALLDataSetTableAdapters.CasesTableAdapter();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.phoneBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.faceKeyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneTypeCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.paymentsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.caseKeyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payKeyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cardNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payDayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.payAmountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otherDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.casesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.casekeyDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loanDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.casecodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accountservedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.posodaneiouDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aliktokefalaioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.epitokioDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lixiprothesmoposoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statementbalanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tokoiDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hmniaanathesisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.flagDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lixidaneioukartasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kodkatastimatosDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kodanathesisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalbalanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalbalanceanathesisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aliktoposoanathesisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lixiprothesmoanathesisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.availablespendingbalanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kodanaklisisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bucketDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imereskathisterisisDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.skoposdaneiouDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.fIRSTCALLDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fIRSTCALLDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.casesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.casesBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(497, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(497, 93);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // fIRSTCALLDataSetBindingSource
            // 
            this.fIRSTCALLDataSetBindingSource.DataSource = this.fIRSTCALLDataSet;
            this.fIRSTCALLDataSetBindingSource.Position = 0;
            // 
            // fIRSTCALLDataSet
            // 
            this.fIRSTCALLDataSet.DataSetName = "FIRSTCALLDataSet";
            this.fIRSTCALLDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // phoneBindingSource
            // 
            this.phoneBindingSource.DataMember = "Phone";
            this.phoneBindingSource.DataSource = this.fIRSTCALLDataSetBindingSource;
            // 
            // phoneTableAdapter
            // 
            this.phoneTableAdapter.ClearBeforeFill = true;
            // 
            // phoneBindingSource1
            // 
            this.phoneBindingSource1.DataMember = "Phone";
            this.phoneBindingSource1.DataSource = this.fIRSTCALLDataSetBindingSource;
            // 
            // paymentsBindingSource
            // 
            this.paymentsBindingSource.DataMember = "Payments";
            this.paymentsBindingSource.DataSource = this.fIRSTCALLDataSetBindingSource;
            // 
            // paymentsTableAdapter
            // 
            this.paymentsTableAdapter.ClearBeforeFill = true;
            // 
            // casesBindingSource
            // 
            this.casesBindingSource.DataMember = "Cases";
            this.casesBindingSource.DataSource = this.fIRSTCALLDataSetBindingSource;
            // 
            // casesTableAdapter
            // 
            this.casesTableAdapter.ClearBeforeFill = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(28, 33);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.faceKeyDataGridViewTextBoxColumn,
            this.clientCodeDataGridViewTextBoxColumn,
            this.phoneTypeCodeDataGridViewTextBoxColumn,
            this.phoneNumberDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.phoneBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(28, 245);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 4;
            // 
            // phoneBindingSource2
            // 
            this.phoneBindingSource2.DataMember = "Phone";
            this.phoneBindingSource2.DataSource = this.fIRSTCALLDataSetBindingSource;
            // 
            // faceKeyDataGridViewTextBoxColumn
            // 
            this.faceKeyDataGridViewTextBoxColumn.DataPropertyName = "FaceKey";
            this.faceKeyDataGridViewTextBoxColumn.HeaderText = "FaceKey";
            this.faceKeyDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.faceKeyDataGridViewTextBoxColumn.Name = "faceKeyDataGridViewTextBoxColumn";
            this.faceKeyDataGridViewTextBoxColumn.Width = 125;
            // 
            // clientCodeDataGridViewTextBoxColumn
            // 
            this.clientCodeDataGridViewTextBoxColumn.DataPropertyName = "ClientCode";
            this.clientCodeDataGridViewTextBoxColumn.HeaderText = "ClientCode";
            this.clientCodeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.clientCodeDataGridViewTextBoxColumn.Name = "clientCodeDataGridViewTextBoxColumn";
            this.clientCodeDataGridViewTextBoxColumn.Width = 125;
            // 
            // phoneTypeCodeDataGridViewTextBoxColumn
            // 
            this.phoneTypeCodeDataGridViewTextBoxColumn.DataPropertyName = "PhoneTypeCode";
            this.phoneTypeCodeDataGridViewTextBoxColumn.HeaderText = "PhoneTypeCode";
            this.phoneTypeCodeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phoneTypeCodeDataGridViewTextBoxColumn.Name = "phoneTypeCodeDataGridViewTextBoxColumn";
            this.phoneTypeCodeDataGridViewTextBoxColumn.Width = 125;
            // 
            // phoneNumberDataGridViewTextBoxColumn
            // 
            this.phoneNumberDataGridViewTextBoxColumn.DataPropertyName = "PhoneNumber";
            this.phoneNumberDataGridViewTextBoxColumn.HeaderText = "PhoneNumber";
            this.phoneNumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phoneNumberDataGridViewTextBoxColumn.Name = "phoneNumberDataGridViewTextBoxColumn";
            this.phoneNumberDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.caseKeyDataGridViewTextBoxColumn,
            this.payKeyDataGridViewTextBoxColumn,
            this.cardNoDataGridViewTextBoxColumn,
            this.payDayDataGridViewTextBoxColumn,
            this.payAmountDataGridViewTextBoxColumn,
            this.otherDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.paymentsBindingSource1;
            this.dataGridView2.Location = new System.Drawing.Point(302, 245);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(240, 150);
            this.dataGridView2.TabIndex = 5;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // paymentsBindingSource1
            // 
            this.paymentsBindingSource1.DataMember = "Payments";
            this.paymentsBindingSource1.DataSource = this.fIRSTCALLDataSetBindingSource;
            // 
            // caseKeyDataGridViewTextBoxColumn
            // 
            this.caseKeyDataGridViewTextBoxColumn.DataPropertyName = "CaseKey";
            this.caseKeyDataGridViewTextBoxColumn.HeaderText = "CaseKey";
            this.caseKeyDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.caseKeyDataGridViewTextBoxColumn.Name = "caseKeyDataGridViewTextBoxColumn";
            this.caseKeyDataGridViewTextBoxColumn.Width = 125;
            // 
            // payKeyDataGridViewTextBoxColumn
            // 
            this.payKeyDataGridViewTextBoxColumn.DataPropertyName = "PayKey";
            this.payKeyDataGridViewTextBoxColumn.HeaderText = "PayKey";
            this.payKeyDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.payKeyDataGridViewTextBoxColumn.Name = "payKeyDataGridViewTextBoxColumn";
            this.payKeyDataGridViewTextBoxColumn.Width = 125;
            // 
            // cardNoDataGridViewTextBoxColumn
            // 
            this.cardNoDataGridViewTextBoxColumn.DataPropertyName = "CardNo";
            this.cardNoDataGridViewTextBoxColumn.HeaderText = "CardNo";
            this.cardNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cardNoDataGridViewTextBoxColumn.Name = "cardNoDataGridViewTextBoxColumn";
            this.cardNoDataGridViewTextBoxColumn.Width = 125;
            // 
            // payDayDataGridViewTextBoxColumn
            // 
            this.payDayDataGridViewTextBoxColumn.DataPropertyName = "PayDay";
            this.payDayDataGridViewTextBoxColumn.HeaderText = "PayDay";
            this.payDayDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.payDayDataGridViewTextBoxColumn.Name = "payDayDataGridViewTextBoxColumn";
            this.payDayDataGridViewTextBoxColumn.Width = 125;
            // 
            // payAmountDataGridViewTextBoxColumn
            // 
            this.payAmountDataGridViewTextBoxColumn.DataPropertyName = "PayAmount";
            this.payAmountDataGridViewTextBoxColumn.HeaderText = "PayAmount";
            this.payAmountDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.payAmountDataGridViewTextBoxColumn.Name = "payAmountDataGridViewTextBoxColumn";
            this.payAmountDataGridViewTextBoxColumn.Width = 125;
            // 
            // otherDataGridViewTextBoxColumn
            // 
            this.otherDataGridViewTextBoxColumn.DataPropertyName = "Other";
            this.otherDataGridViewTextBoxColumn.HeaderText = "Other";
            this.otherDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.otherDataGridViewTextBoxColumn.Name = "otherDataGridViewTextBoxColumn";
            this.otherDataGridViewTextBoxColumn.Width = 125;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.casekeyDataGridViewTextBoxColumn1,
            this.loanDataGridViewTextBoxColumn,
            this.casecodeDataGridViewTextBoxColumn,
            this.accountservedDataGridViewTextBoxColumn,
            this.productcodeDataGridViewTextBoxColumn,
            this.posodaneiouDataGridViewTextBoxColumn,
            this.aliktokefalaioDataGridViewTextBoxColumn,
            this.epitokioDataGridViewTextBoxColumn,
            this.lixiprothesmoposoDataGridViewTextBoxColumn,
            this.statementbalanceDataGridViewTextBoxColumn,
            this.tokoiDataGridViewTextBoxColumn,
            this.hmniaanathesisDataGridViewTextBoxColumn,
            this.flagDataGridViewTextBoxColumn,
            this.lixidaneioukartasDataGridViewTextBoxColumn,
            this.kodkatastimatosDataGridViewTextBoxColumn,
            this.kodanathesisDataGridViewTextBoxColumn,
            this.totalbalanceDataGridViewTextBoxColumn,
            this.totalbalanceanathesisDataGridViewTextBoxColumn,
            this.aliktoposoanathesisDataGridViewTextBoxColumn,
            this.lixiprothesmoanathesisDataGridViewTextBoxColumn,
            this.availablespendingbalanceDataGridViewTextBoxColumn,
            this.kodanaklisisDataGridViewTextBoxColumn,
            this.bucketDataGridViewTextBoxColumn,
            this.imereskathisterisisDataGridViewTextBoxColumn,
            this.skoposdaneiouDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.casesBindingSource1;
            this.dataGridView3.Location = new System.Drawing.Point(584, 245);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(240, 150);
            this.dataGridView3.TabIndex = 6;
            // 
            // casesBindingSource1
            // 
            this.casesBindingSource1.DataMember = "Cases";
            this.casesBindingSource1.DataSource = this.fIRSTCALLDataSetBindingSource;
            // 
            // casekeyDataGridViewTextBoxColumn1
            // 
            this.casekeyDataGridViewTextBoxColumn1.DataPropertyName = "casekey";
            this.casekeyDataGridViewTextBoxColumn1.HeaderText = "casekey";
            this.casekeyDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.casekeyDataGridViewTextBoxColumn1.Name = "casekeyDataGridViewTextBoxColumn1";
            this.casekeyDataGridViewTextBoxColumn1.Width = 125;
            // 
            // loanDataGridViewTextBoxColumn
            // 
            this.loanDataGridViewTextBoxColumn.DataPropertyName = "loan";
            this.loanDataGridViewTextBoxColumn.HeaderText = "loan";
            this.loanDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.loanDataGridViewTextBoxColumn.Name = "loanDataGridViewTextBoxColumn";
            this.loanDataGridViewTextBoxColumn.Width = 125;
            // 
            // casecodeDataGridViewTextBoxColumn
            // 
            this.casecodeDataGridViewTextBoxColumn.DataPropertyName = "casecode";
            this.casecodeDataGridViewTextBoxColumn.HeaderText = "casecode";
            this.casecodeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.casecodeDataGridViewTextBoxColumn.Name = "casecodeDataGridViewTextBoxColumn";
            this.casecodeDataGridViewTextBoxColumn.Width = 125;
            // 
            // accountservedDataGridViewTextBoxColumn
            // 
            this.accountservedDataGridViewTextBoxColumn.DataPropertyName = "accountserved";
            this.accountservedDataGridViewTextBoxColumn.HeaderText = "accountserved";
            this.accountservedDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.accountservedDataGridViewTextBoxColumn.Name = "accountservedDataGridViewTextBoxColumn";
            this.accountservedDataGridViewTextBoxColumn.Width = 125;
            // 
            // productcodeDataGridViewTextBoxColumn
            // 
            this.productcodeDataGridViewTextBoxColumn.DataPropertyName = "productcode";
            this.productcodeDataGridViewTextBoxColumn.HeaderText = "productcode";
            this.productcodeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.productcodeDataGridViewTextBoxColumn.Name = "productcodeDataGridViewTextBoxColumn";
            this.productcodeDataGridViewTextBoxColumn.Width = 125;
            // 
            // posodaneiouDataGridViewTextBoxColumn
            // 
            this.posodaneiouDataGridViewTextBoxColumn.DataPropertyName = "posodaneiou";
            this.posodaneiouDataGridViewTextBoxColumn.HeaderText = "posodaneiou";
            this.posodaneiouDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.posodaneiouDataGridViewTextBoxColumn.Name = "posodaneiouDataGridViewTextBoxColumn";
            this.posodaneiouDataGridViewTextBoxColumn.Width = 125;
            // 
            // aliktokefalaioDataGridViewTextBoxColumn
            // 
            this.aliktokefalaioDataGridViewTextBoxColumn.DataPropertyName = "aliktokefalaio";
            this.aliktokefalaioDataGridViewTextBoxColumn.HeaderText = "aliktokefalaio";
            this.aliktokefalaioDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aliktokefalaioDataGridViewTextBoxColumn.Name = "aliktokefalaioDataGridViewTextBoxColumn";
            this.aliktokefalaioDataGridViewTextBoxColumn.Width = 125;
            // 
            // epitokioDataGridViewTextBoxColumn
            // 
            this.epitokioDataGridViewTextBoxColumn.DataPropertyName = "epitokio";
            this.epitokioDataGridViewTextBoxColumn.HeaderText = "epitokio";
            this.epitokioDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.epitokioDataGridViewTextBoxColumn.Name = "epitokioDataGridViewTextBoxColumn";
            this.epitokioDataGridViewTextBoxColumn.Width = 125;
            // 
            // lixiprothesmoposoDataGridViewTextBoxColumn
            // 
            this.lixiprothesmoposoDataGridViewTextBoxColumn.DataPropertyName = "lixiprothesmoposo";
            this.lixiprothesmoposoDataGridViewTextBoxColumn.HeaderText = "lixiprothesmoposo";
            this.lixiprothesmoposoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lixiprothesmoposoDataGridViewTextBoxColumn.Name = "lixiprothesmoposoDataGridViewTextBoxColumn";
            this.lixiprothesmoposoDataGridViewTextBoxColumn.Width = 125;
            // 
            // statementbalanceDataGridViewTextBoxColumn
            // 
            this.statementbalanceDataGridViewTextBoxColumn.DataPropertyName = "statementbalance";
            this.statementbalanceDataGridViewTextBoxColumn.HeaderText = "statementbalance";
            this.statementbalanceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.statementbalanceDataGridViewTextBoxColumn.Name = "statementbalanceDataGridViewTextBoxColumn";
            this.statementbalanceDataGridViewTextBoxColumn.Width = 125;
            // 
            // tokoiDataGridViewTextBoxColumn
            // 
            this.tokoiDataGridViewTextBoxColumn.DataPropertyName = "tokoi";
            this.tokoiDataGridViewTextBoxColumn.HeaderText = "tokoi";
            this.tokoiDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.tokoiDataGridViewTextBoxColumn.Name = "tokoiDataGridViewTextBoxColumn";
            this.tokoiDataGridViewTextBoxColumn.Width = 125;
            // 
            // hmniaanathesisDataGridViewTextBoxColumn
            // 
            this.hmniaanathesisDataGridViewTextBoxColumn.DataPropertyName = "hmniaanathesis";
            this.hmniaanathesisDataGridViewTextBoxColumn.HeaderText = "hmniaanathesis";
            this.hmniaanathesisDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.hmniaanathesisDataGridViewTextBoxColumn.Name = "hmniaanathesisDataGridViewTextBoxColumn";
            this.hmniaanathesisDataGridViewTextBoxColumn.Width = 125;
            // 
            // flagDataGridViewTextBoxColumn
            // 
            this.flagDataGridViewTextBoxColumn.DataPropertyName = "flag";
            this.flagDataGridViewTextBoxColumn.HeaderText = "flag";
            this.flagDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.flagDataGridViewTextBoxColumn.Name = "flagDataGridViewTextBoxColumn";
            this.flagDataGridViewTextBoxColumn.Width = 125;
            // 
            // lixidaneioukartasDataGridViewTextBoxColumn
            // 
            this.lixidaneioukartasDataGridViewTextBoxColumn.DataPropertyName = "lixidaneioukartas";
            this.lixidaneioukartasDataGridViewTextBoxColumn.HeaderText = "lixidaneioukartas";
            this.lixidaneioukartasDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lixidaneioukartasDataGridViewTextBoxColumn.Name = "lixidaneioukartasDataGridViewTextBoxColumn";
            this.lixidaneioukartasDataGridViewTextBoxColumn.Width = 125;
            // 
            // kodkatastimatosDataGridViewTextBoxColumn
            // 
            this.kodkatastimatosDataGridViewTextBoxColumn.DataPropertyName = "kodkatastimatos";
            this.kodkatastimatosDataGridViewTextBoxColumn.HeaderText = "kodkatastimatos";
            this.kodkatastimatosDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kodkatastimatosDataGridViewTextBoxColumn.Name = "kodkatastimatosDataGridViewTextBoxColumn";
            this.kodkatastimatosDataGridViewTextBoxColumn.Width = 125;
            // 
            // kodanathesisDataGridViewTextBoxColumn
            // 
            this.kodanathesisDataGridViewTextBoxColumn.DataPropertyName = "kodanathesis";
            this.kodanathesisDataGridViewTextBoxColumn.HeaderText = "kodanathesis";
            this.kodanathesisDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kodanathesisDataGridViewTextBoxColumn.Name = "kodanathesisDataGridViewTextBoxColumn";
            this.kodanathesisDataGridViewTextBoxColumn.Width = 125;
            // 
            // totalbalanceDataGridViewTextBoxColumn
            // 
            this.totalbalanceDataGridViewTextBoxColumn.DataPropertyName = "totalbalance";
            this.totalbalanceDataGridViewTextBoxColumn.HeaderText = "totalbalance";
            this.totalbalanceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.totalbalanceDataGridViewTextBoxColumn.Name = "totalbalanceDataGridViewTextBoxColumn";
            this.totalbalanceDataGridViewTextBoxColumn.Width = 125;
            // 
            // totalbalanceanathesisDataGridViewTextBoxColumn
            // 
            this.totalbalanceanathesisDataGridViewTextBoxColumn.DataPropertyName = "totalbalanceanathesis";
            this.totalbalanceanathesisDataGridViewTextBoxColumn.HeaderText = "totalbalanceanathesis";
            this.totalbalanceanathesisDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.totalbalanceanathesisDataGridViewTextBoxColumn.Name = "totalbalanceanathesisDataGridViewTextBoxColumn";
            this.totalbalanceanathesisDataGridViewTextBoxColumn.Width = 125;
            // 
            // aliktoposoanathesisDataGridViewTextBoxColumn
            // 
            this.aliktoposoanathesisDataGridViewTextBoxColumn.DataPropertyName = "aliktoposoanathesis";
            this.aliktoposoanathesisDataGridViewTextBoxColumn.HeaderText = "aliktoposoanathesis";
            this.aliktoposoanathesisDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.aliktoposoanathesisDataGridViewTextBoxColumn.Name = "aliktoposoanathesisDataGridViewTextBoxColumn";
            this.aliktoposoanathesisDataGridViewTextBoxColumn.Width = 125;
            // 
            // lixiprothesmoanathesisDataGridViewTextBoxColumn
            // 
            this.lixiprothesmoanathesisDataGridViewTextBoxColumn.DataPropertyName = "lixiprothesmoanathesis";
            this.lixiprothesmoanathesisDataGridViewTextBoxColumn.HeaderText = "lixiprothesmoanathesis";
            this.lixiprothesmoanathesisDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lixiprothesmoanathesisDataGridViewTextBoxColumn.Name = "lixiprothesmoanathesisDataGridViewTextBoxColumn";
            this.lixiprothesmoanathesisDataGridViewTextBoxColumn.Width = 125;
            // 
            // availablespendingbalanceDataGridViewTextBoxColumn
            // 
            this.availablespendingbalanceDataGridViewTextBoxColumn.DataPropertyName = "availablespendingbalance";
            this.availablespendingbalanceDataGridViewTextBoxColumn.HeaderText = "availablespendingbalance";
            this.availablespendingbalanceDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.availablespendingbalanceDataGridViewTextBoxColumn.Name = "availablespendingbalanceDataGridViewTextBoxColumn";
            this.availablespendingbalanceDataGridViewTextBoxColumn.Width = 125;
            // 
            // kodanaklisisDataGridViewTextBoxColumn
            // 
            this.kodanaklisisDataGridViewTextBoxColumn.DataPropertyName = "kodanaklisis";
            this.kodanaklisisDataGridViewTextBoxColumn.HeaderText = "kodanaklisis";
            this.kodanaklisisDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.kodanaklisisDataGridViewTextBoxColumn.Name = "kodanaklisisDataGridViewTextBoxColumn";
            this.kodanaklisisDataGridViewTextBoxColumn.Width = 125;
            // 
            // bucketDataGridViewTextBoxColumn
            // 
            this.bucketDataGridViewTextBoxColumn.DataPropertyName = "bucket";
            this.bucketDataGridViewTextBoxColumn.HeaderText = "bucket";
            this.bucketDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.bucketDataGridViewTextBoxColumn.Name = "bucketDataGridViewTextBoxColumn";
            this.bucketDataGridViewTextBoxColumn.Width = 125;
            // 
            // imereskathisterisisDataGridViewTextBoxColumn
            // 
            this.imereskathisterisisDataGridViewTextBoxColumn.DataPropertyName = "imereskathisterisis";
            this.imereskathisterisisDataGridViewTextBoxColumn.HeaderText = "imereskathisterisis";
            this.imereskathisterisisDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.imereskathisterisisDataGridViewTextBoxColumn.Name = "imereskathisterisisDataGridViewTextBoxColumn";
            this.imereskathisterisisDataGridViewTextBoxColumn.Width = 125;
            // 
            // skoposdaneiouDataGridViewTextBoxColumn
            // 
            this.skoposdaneiouDataGridViewTextBoxColumn.DataPropertyName = "skoposdaneiou";
            this.skoposdaneiouDataGridViewTextBoxColumn.HeaderText = "skoposdaneiou";
            this.skoposdaneiouDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.skoposdaneiouDataGridViewTextBoxColumn.Name = "skoposdaneiouDataGridViewTextBoxColumn";
            this.skoposdaneiouDataGridViewTextBoxColumn.Width = 125;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 450);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fIRSTCALLDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fIRSTCALLDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.casesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phoneBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.casesBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.BindingSource fIRSTCALLDataSetBindingSource;
        private FIRSTCALLDataSet fIRSTCALLDataSet;
        private System.Windows.Forms.BindingSource phoneBindingSource;
        private FIRSTCALLDataSetTableAdapters.PhoneTableAdapter phoneTableAdapter;
        private System.Windows.Forms.BindingSource phoneBindingSource1;
        private System.Windows.Forms.BindingSource paymentsBindingSource;
        private FIRSTCALLDataSetTableAdapters.PaymentsTableAdapter paymentsTableAdapter;
        private System.Windows.Forms.BindingSource casesBindingSource;
        private FIRSTCALLDataSetTableAdapters.CasesTableAdapter casesTableAdapter;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn faceKeyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn clientCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneTypeCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource phoneBindingSource2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn caseKeyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn payKeyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cardNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn payDayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn payAmountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otherDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource paymentsBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn casekeyDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn loanDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn casecodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn accountservedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn posodaneiouDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aliktokefalaioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn epitokioDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lixiprothesmoposoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statementbalanceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn tokoiDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn hmniaanathesisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn flagDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lixidaneioukartasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kodkatastimatosDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kodanathesisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalbalanceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalbalanceanathesisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aliktoposoanathesisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lixiprothesmoanathesisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn availablespendingbalanceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn kodanaklisisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn bucketDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imereskathisterisisDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn skoposdaneiouDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource casesBindingSource1;
    }
}

