﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ionic.Zip;

namespace FirstCall
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadDebtors();
            if (comboBox1.SelectedValue != null)
                ShowDebtorInfo(comboBox1.SelectedValue.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Choose the ZIP file
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Filter = "Zip Files|*.zip";
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string zipPath = openFileDialog.FileName;

                        // Choose destination folder
                        using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
                        {
                            if (folderDialog.ShowDialog() == DialogResult.OK)
                            {
                                string extractPath = folderDialog.SelectedPath;

                                using (ZipFile zip = ZipFile.Read(zipPath))
                                {
                                    zip.Password = "FirstCall13"; // Password
                                    foreach (ZipEntry entry in zip)
                                    {
                                        entry.Extract(extractPath, ExtractExistingFileAction.OverwriteSilently);
                                    }
                                }

                                MessageBox.Show("Unzipped successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Process process = new Process();
                process.StartInfo.FileName = @"C:\Program Files\Microsoft SQL Server\150\DTS\Binn\dtexec.exe";
                process.StartInfo.Arguments = "/F \"C:\\Users\\tasos\\Desktop\\LoadTxtData\\Package.dtsx\"";
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardOutput = true;
                process.Start();

                string output = process.StandardOutput.ReadToEnd();
                process.WaitForExit();

                MessageBox.Show("Package execution finished:\n" + output);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing package:\n" + ex.Message);
            }
        }
        // === LOAD DEBTORS INTO COMBOBOX ===
        private void LoadDebtors()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Server=DESKTOP-5HFE92F\\SQLEXPRESS;Database=FIRSTCALL;Integrated Security=True;"))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("SELECT CAST(facekey AS VARCHAR(MAX)) AS facekey, lastname, firstname FROM Persons ORDER BY lastname", conn);
                    SqlDataReader reader = cmd.ExecuteReader();

                    DataTable dt = new DataTable();
                    dt.Load(reader);

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "lastname" + "firstname";
                    comboBox1.ValueMember = "facekey";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading debtors: " + ex.Message);
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue != null)
                ShowDebtorInfo(comboBox1.SelectedValue.ToString());
        }
        private void ShowDebtorInfo(string facekey)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Server=DESKTOP-5HFE92F\\SQLEXPRESS;Database=FIRSTCALL;Integrated Security=True;"))
                {
                    conn.Open();

                    // Phones
                    SqlDataAdapter daPhones = new SqlDataAdapter(
                        "SELECT FaceKey,ClientCode,PhoneTypeCode,PhoneNumber FROM Phone WHERE CAST(facekey AS VARCHAR(MAX)) = @facekey", conn);
                    daPhones.SelectCommand.Parameters.AddWithValue("@facekey", facekey);
                    DataTable dtPhones = new DataTable();
                    daPhones.Fill(dtPhones);
                    dataGridView1.DataSource = dtPhones;

                    // Payments
                    SqlDataAdapter daPayments = new SqlDataAdapter(@"
                        SELECT pay.*
                        FROM Payments pay
                        JOIN Relations r ON CAST(c.casekey AS VARCHAR(MAX)) = CAST(r.casekey AS VARCHAR(MAX))
                        JOIN Persons p ON CAST(r.facekey AS VARCHAR(MAX)) = CAST(p.facekey AS VARCHAR(MAX))
                        LEFT JOIN Payments pay ON CAST(c.casekey AS VARCHAR(MAX)) = CAST(pay.casekey AS VARCHAR(MAX))
                        WHERE CAST(p.facekey AS VARCHAR(MAX)) = @facekey", conn);
                    daPayments.SelectCommand.Parameters.AddWithValue("@facekey", facekey);
                    DataTable dtPayments = new DataTable();
                    daPayments.Fill(dtPayments);
                    dataGridView2.DataSource = dtPayments;

                    // Cases
                    SqlDataAdapter daCases = new SqlDataAdapter(@"
                        SELECT c.*
                        FROM Cases c
                        JOIN Relations r ON CAST(c.casekey AS VARCHAR(MAX)) = CAST(r.casekey AS VARCHAR(MAX))
                        WHERE CAST(r.facekey AS VARCHAR(MAX)) = @facekey", conn);
                    daCases.SelectCommand.Parameters.AddWithValue("@facekey", facekey);
                    DataTable dtCases = new DataTable();
                    daCases.Fill(dtCases);
                    dataGridView3.DataSource = dtCases;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading debtor card: " + ex.Message);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'fIRSTCALLDataSet.Cases' table. You can move, or remove it, as needed.
            this.casesTableAdapter.Fill(this.fIRSTCALLDataSet.Cases);
            // TODO: This line of code loads data into the 'fIRSTCALLDataSet.Payments' table. You can move, or remove it, as needed.
            this.paymentsTableAdapter.Fill(this.fIRSTCALLDataSet.Payments);

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

}
